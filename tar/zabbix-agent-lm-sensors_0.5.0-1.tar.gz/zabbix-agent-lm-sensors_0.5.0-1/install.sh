#!/bin/bash

  cp "$(dirname $0)/zabbix-agent-lm-sensors" /usr/bin/

  if [ -e /etc/zabbix/zabbix_agentd.d ] ; then
    zabbix-agent-lm-sensors config > /etc/zabbix/zabbix_agentd.d/userparameter_lm_sensors.conf
  fi
