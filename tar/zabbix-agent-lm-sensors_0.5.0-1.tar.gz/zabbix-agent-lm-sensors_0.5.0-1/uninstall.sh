#!/bin/bash

  if [[ -e /usr/bin/zabbix-agent-lm-sensors ]] ; then
    rm -f /usr/bin/zabbix-agent-lm-sensors
  fi

  if [[ -e /etc/zabbix/zabbix_agentd.d/userparameter_lm_sensors.conf ]] ; then
    rm -f /etc/zabbix/zabbix_agentd.d/userparameter_lm_sensors.conf
  fi
